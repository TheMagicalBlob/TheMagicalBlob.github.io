# Naughty Dog Debug Mode Enabler

I Decided To Make A Tool To Make Enabling The Debug Mode In *Any* PS4 Naughty Dog Game As Quick As Possible, Rather Than People Needing To Look For Some Codes
Online And Apply Them Manually, And Also Included Modified Versions Of The Menus That You Can't Get Anywhere Else. (Ignoring Any Potential Leaked Builds That Are Being Hoarded...)

These Range From Just Having Some Useless Options Replaced With Some Normally Inaccessible Ones (Tlou2), To Unlocking Entire Devkit Menus
Dozens Of Times Bigger Than The Default Ones (UC1/2/3) 


**It Has Two Functions:**

- The First Uses libdebug &amp; PS4Debug to enable the debug modes of any of the PS4 Naughty Dog games.
- The Second Either Enables The Debug Mode As-is In The Game, Or Patches In The Restored Version With More Options

All Offsets & Codes Are From Myself Only, But I Have No Part In PS4Debug/libdebug

*Special Thanks To illusion For Introducing Me To Ghidra A Few Years Back*

**-** TheMagicalBlob
